
package br.edu.fatec.ex2;

public class teste {

    public static void main(String[] args) {
        Aluno obj1 = new Aluno(123456, 10, 5, 5, "Pedro");
        obj1.notaFinal(5);
        obj1.dadosAluno();
    }
    
}
